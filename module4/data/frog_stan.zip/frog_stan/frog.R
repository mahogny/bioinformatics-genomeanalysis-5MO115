#install.packages("rstan")

library(ggplot2)
library("rstan")
options(mc.cores=4)  ## set based on how many CPUs you use for your session


frogdat <- read.csv("frogs.csv")


# Prepare STAN model
model <- stan_model("frog.stan")

# Simulate model
fit = sampling(model,list(
  N=nrow(frogdat),
  time=frogdat$time,
  y=frogdat$y
),iter=2000,chains=4)

# Get samples of parameters
params <- extract(fit)

# Just to give an idea of how the MCMC algorithm in STAN has traveled across
# different values. Way beyond this course to explain how this algorithm works!
ggplot(
  data.frame(time=seq_along(params$lambda_start), lambda_start=params$lambda_start),
  aes(time, lambda_start)) + geom_line()


# Quick idea of averages of parameters
mean(params$lambda_start)
mean(params$lambda_end)

## Compute average samples, from first to last time point
frogdat$p.mean <- colMeans(params$lambda)
frogdat$p.sd <- MatrixGenerics::colSds(params$lambda, useNames = FALSE)
frogdat$p.upper <- frogdat$p.mean + 2*frogdat$p.sd
frogdat$p.lower <- frogdat$p.mean - 2*frogdat$p.sd

## Fitted lambda, +-2sd confidence interval  (95%)
ggplot(frogdat, aes(time,p.mean)) + geom_line() + #ylim(0,1) +
  geom_line(data=frogdat, aes(time,p.upper), color="red")+
  geom_line(data=frogdat, aes(time,p.lower), color="red")
  
## What is the likelihood distribution of different lambda?
hist(params$lambda_start-params$lambda_end)


