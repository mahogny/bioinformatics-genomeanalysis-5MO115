data {
  int<lower=0> N; // number of time points
  real time[N];   // time points = 0...J / J
  int y[N];       // count at each time point
} 
parameters {
  // Line parameters -- here defined to ensure lambda is always positive
  // y=ktime+m also works but STAN might misbehave because it does not fulfill above
  real<lower=0> lambda_start;
  real<lower=0> lambda_end;
} 
transformed parameters {
  real lambda[N];
  for(i in 1:N){
    lambda[i] = (1-time[i])*lambda_start + time[i]*lambda_end; // lambda = ktime+m
  }
}
model {
  
  y ~ poisson(lambda);
  
}


