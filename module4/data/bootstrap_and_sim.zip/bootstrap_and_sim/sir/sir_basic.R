library(ggplot2)


beta <- 0.1
gamma <- 0.1

#Starting conditions
indiv <- data.frame(num=1:20, state="S")
indiv$state[1] <- "I"

log_num_SIR <- NULL
for(curday in 1:50){
  log_num_SIR <- rbind(log_num_SIR, data.frame(
    S=sum(indiv$state=="S"),
    I=sum(indiv$state=="I"),
    R=sum(indiv$state=="R")
  ))
  
  #Assume no change in state in the next time point unless set
  next_indiv <- indiv

  #Who becomes infected?
  num_inf <- sum(indiv$state=="I")
  current_infection_rate <- num_inf*beta
  next_indiv$state[indiv$state=="S" & runif(nrow(indiv)) < current_infection_rate] <- "I"
  
  #Who clears infection?
  next_indiv$state[indiv$state=="I" & runif(nrow(indiv)) < gamma] <- "R"
  
  indiv <- next_indiv
}

#### Plot stats over time
df <- reshape2::melt(as.matrix(log_num_SIR))
colnames(df) <- c("Day","State","cnt")
ggplot(df, aes(Day,cnt, color=State)) + geom_step()


