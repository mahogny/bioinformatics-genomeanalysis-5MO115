library(ggplot2)


beta <- 0.1
gamma <- 0.1
kappa <- 0.02

#Starting conditions
indiv <- data.frame(num=1:20, state="S", house="1")
indiv$state[1] <- "I"
indiv$house[11:20] <- "2"


log_num_SIR <- NULL
for(curday in 1:100){
  log_num_SIR <- rbind(log_num_SIR, data.frame(
    S1=sum(indiv$state=="S" & indiv$house=="1"),
    I1=sum(indiv$state=="I" & indiv$house=="1"),
    R1=sum(indiv$state=="R" & indiv$house=="1"),
    
    S2=sum(indiv$state=="S" & indiv$house=="2"),
    I2=sum(indiv$state=="I" & indiv$house=="2"),
    R2=sum(indiv$state=="R" & indiv$house=="2")
  ))
  
  #Assume no change in state in the next time point unless set
  next_indiv <- indiv

  ### Each house has separate dynamics for infection
  for(cur_house in c("1","2")){
    #Who becomes infected?
    num_inf <- sum(indiv$state=="I" & indiv$house==cur_house)
    current_infection_rate <- num_inf*beta
    next_indiv$state[indiv$state=="S" & indiv$house==cur_house & 
                       runif(nrow(indiv)) < current_infection_rate] <- "I"
  }
  
  #Who clears infection?
  next_indiv$state[indiv$state=="I" & runif(nrow(indiv)) < gamma] <- "R"
  
  #People move at the end of the day
  next_indiv$house[indiv$house=="1" & runif(nrow(indiv)) < kappa] <- "2"
  next_indiv$house[indiv$house=="2" & runif(nrow(indiv)) < kappa] <- "1"
  
  indiv <- next_indiv
}

#### Plot stats over time
df <- reshape2::melt(as.matrix(log_num_SIR))
colnames(df) <- c("Day","State","cnt")
ggplot(df, aes(Day,cnt, color=State)) + geom_step()


next_indiv
