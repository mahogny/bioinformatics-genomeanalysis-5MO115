library(ggplot2)


### The real distribution is the uniform distribution [0,1]

X <- runif(10000,0,1)

ggplot(data.frame(x=X), aes(x)) + 
  geom_histogram(bins=30) + 
  geom_hline(yintercept = length(X)/30, color="red")



### Bootstraps of the mean

X <- runif(100,0,1)

bootstraps <- rep(NA, 10000)
for(i in 1:length(bootstraps)){
  bootstraps[i] <- mean(sample(X, length(X), replace = TRUE))
}
hist(bootstraps, breaks=100)

mean(bootstraps>0.6)






### Sin(X), X normal distribution

X <- rnorm(10000,0,2*pi)
hist(X, breaks=100)
hist(sin(X), breaks=100)



mean(abs(sin(X))<0.5)

