library(ggplot2)


numpos <- 50
pos <- data.frame(x=rep(NA,numpos), y=rep(NA,numpos))
pos$x[1] <- 0 #starting position
pos$y[1] <- 0
for(i in 2:nrow(pos)){
  print(i)
  lastx <- pos$x[i-1] # Figure out current starting point
  lasty <- pos$y[i-1]
  
  #Keep trying to find next point, forbidding self-intersection.
  #This can crash at times!
  while(TRUE){
    dirlist <- list(c(0,+1), c(0,-1), c(-1,0), c(+1,0))
    pickdir <- dirlist[[sample(1:4,1)]]
    nx <- lastx + pickdir[1]
    ny <- lasty + pickdir[2]
    lastpos <- pos[1:(i-1), , drop=FALSE]
    
    
    if(!any(lastpos$x==nx & lastpos$y==ny)){
      #No collision!
      pos$x[i] <- nx
      pos$y[i] <- ny
      break;
    }
  }  
}

#Note: geom_line assumes a function of type y=f(x) and automatically sorts
#the points. This does not work here. geom_path is more general
ggplot(pos, aes(x,y)) + geom_path()

polymerDistance <- function(pos){
  dx <- pos$x[nrow(pos)] - pos$x[1]
  dy <- pos$y[nrow(pos)] - pos$y[1]
  distance <- sqrt(dx**2 + dy**2)
  distance
}

polymerDistance(pos)

