library(ggplot2)

simulateWalk <- function(numpos=100, allow_selfintersect=FALSE){
  
  numpos <- 100
  pos <- data.frame(x=rep(NA,numpos), y=rep(NA,numpos))
  pos$x[1] <- 0 #starting position
  pos$y[1] <- 0
  for(i in 2:nrow(pos)){
    lastx <- pos$x[i-1] # Figure out current starting point
    lasty <- pos$y[i-1]
    
    #Keep trying to find next point, forbidding self-intersection.
    #This can crash at times!
    dirlist <- list(c(0,+1), c(0,-1), c(-1,0), c(+1,0))
    while(TRUE){
      ind <- sample(1:length(dirlist),1)
      pickdir <- dirlist[[ind]]
      nx <- lastx + pickdir[1]
      ny <- lasty + pickdir[2]
      lastpos <- pos[1:(i-1), , drop=FALSE]
      
      
      if(allow_selfintersect | !any(lastpos$x==nx & lastpos$y==ny)){
        #No collision!
        pos$x[i] <- nx
        pos$y[i] <- ny
        break;
      } else {
        dirlist <- dirlist[-ind] #don't try this direction again
        if(length(dirlist)==1) {
          #print("giving up")
          return(NULL)
        }
      }
    }  
  }
  
  return(pos)
}



polymerDistance <- function(pos){
  dx <- pos$x[nrow(pos)] - pos$x[1]
  dy <- pos$y[nrow(pos)] - pos$y[1]
  distance <- sqrt(dx**2 + dy**2)
  distance
}


####### Simulate lengths with no self intersect
list_dist <- NULL
for(i in 1:1000){
  pos <- simulateWalk(allow_selfintersect = FALSE)
  if(!is.null(pos)){
    list_dist <- c(list_dist, polymerDistance(pos))
  }
}
df1 <- data.frame(len=list_dist, intersect="No")
hist(list_dist)
mean(list_dist)

####### Simulate lengths with self intersect
list_dist <- NULL
for(i in 1:1000){
  pos <- simulateWalk(allow_selfintersect = TRUE)
  if(!is.null(pos)){
    list_dist <- c(list_dist, polymerDistance(pos))
  }
}
hist(list_dist)
mean(list_dist)
df2 <- data.frame(len=list_dist, intersect="Yes")

###### Compare length distributions
df <- rbind(df1,df2)
ggplot(df, aes(len, intersect)) + geom_violin()



#df1 <- data.frame(len=list_dist, intersect="No")






#Note: geom_line assumes a function of type y=f(x) and automatically sorts
#the points. This does not work here. geom_path is more general
ggplot(pos, aes(x,y)) + geom_path()

polymerDistance(pos)

