library(ggplot2)

alpha <- 0.2
beta <- 0.001
gamma <- 0.05
delta <- 0.01

numgen <- 1000
num_prey <- rep(NA, numgen)
num_prey[1] <- 200
num_predator <- rep(NA, numgen)
num_predator[1] <- 200

for(i in 2:numgen){
  
  last_prey <- num_prey[i-1]
  last_predator <- num_predator[i-1]
  
  #How many got eaten, and how many survive?
  num_surviving_prey <- rbinom(1, last_prey,(1-beta)**last_predator)
  num_eaten <- last_prey - num_surviving_prey
  
  # Prey: Surviving + new offspring
  num_prey[i] <- num_surviving_prey + rpois(1, alpha*last_prey)

  # Predators: Surviving + new offspring
  num_predator[i] <- rbinom(1, last_predator, 1-gamma) + rpois(1,delta*num_eaten)
}

#### Plot stats over time
df <- data.frame(
  day=1:numgen,
  num_predator=num_predator,
  num_prey=num_prey
)
p1 <- ggplot(df, aes(day,num_predator)) + geom_step()
p2 <- ggplot(df, aes(day,num_prey)) + geom_step()
egg::ggarrange(p1,p2)

#### Show circularity
ggplot(df, aes(num_prey,num_predator)) + geom_path()





