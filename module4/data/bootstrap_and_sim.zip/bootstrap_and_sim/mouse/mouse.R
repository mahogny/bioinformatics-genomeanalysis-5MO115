library(ggplot2)


############## 
#this is a starting point for one single random walk.


num_positions <- 100  #assuming positions are 1...num_positions
num_time <- 100

#Starting conditions
cur_position <- 666 #TODO

for(curtime in 2:num_time){
  thedir <- sample(c(-1,1),1)
  next_position <- 666 #TODO
  if(666){
    
  } else {
    
  }
  cur_position #TODO set to new value
  
}


#once you get one step to work, wrap it all in a function like this
simulate <- function(){
  #...
  cur_position #this is returned
}


