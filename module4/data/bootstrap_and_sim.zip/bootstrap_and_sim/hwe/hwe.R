library(ggplot2)

#Size of population
popsize <- 20

#Starting conditions. Half individuals are AA, the other are aa
indiv <- data.frame(num=1:popsize, allele1="A", allele2="A")
indiv$allele1[11:popsize] <- "a"
indiv$allele2[11:popsize] <- "a"


log_num <- NULL
for(curday in 1:50){
  log_num <- rbind(log_num, data.frame(
    num_AA=sum(indiv$allele1=="A" & indiv$allele2=="A"),
    num_aa=NA, #TODO
    num_Aa=NA #TODO
  ))
  
  #Figure out parents in the next population.
  #Some may have the same parent
  next_indiv <- data.frame(
    parent1=sample(1:popsize,popsize, replace = TRUE),
    parent2=sample(1:popsize,popsize, replace = TRUE),
    allele1=NA,
    allele2=NA
  )
  
  #Figure out the allele
  for(i in 1:nrow(next_indiv)){
    next_indiv$allele1[i] <- "AAA?"
    next_indiv$allele2[i] <- "AAA?"
    
    #TODO. random choice of alleles from the parents
  }
  
  indiv <- next_indiv
}
