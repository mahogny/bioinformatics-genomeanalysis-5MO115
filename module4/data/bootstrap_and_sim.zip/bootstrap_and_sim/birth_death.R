library(ggplot2)

alpha <- 1

popsize <- rep(NA, 100)
popsize[1] <- 3
for(i in 2:length(popsize)){
  popsize[i] <- rpois(1, alpha * popsize[i-1])
}

#### Plot stats over time
ggplot(data.frame(day=1:length(popsize), cnt=popsize), aes(day,cnt,)) + geom_step()

#### when is population first = 0?
which(popsize==0)[1]  


